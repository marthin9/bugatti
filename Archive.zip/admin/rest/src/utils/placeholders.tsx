export { default as productPlaceholder } from '@/assets/placeholders/product.svg';
export { default as couponPlaceholder } from '@/assets/placeholders/coupon.svg';
export { default as avatarPlaceholder } from '@/assets/placeholders/avatar.svg';
export { default as logoPlaceholder } from '@/assets/placeholders/logo.svg';
export { default as zipPlaceholder } from '@/assets/placeholders/zip.png';
